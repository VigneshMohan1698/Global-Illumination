
//struct Vec4
//{
//    float r; 
//    float g; 
//    float b; 
//    float a;
//};
//typedef Vec4 float4;

